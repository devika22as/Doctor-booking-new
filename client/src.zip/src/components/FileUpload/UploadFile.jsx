import React from 'react'
import ReactDOM from "react-dom";
import { Dropzone, FileMosaic } from "@files-ui/react";


const UploadFile = () => {
    
  const [files, setFiles] = React.useState([]);
  const updateFiles = (incommingFiles) => {
    setFiles(incommingFiles);
  };
  return (
    <div className='files_uploading'>
     <Dropzone onChange={updateFiles} value={files}>
      {files.map((file) => (
        <FileMosaic {...file} preview />
      ))}
    </Dropzone> 

    </div>
  )
}

export default UploadFile
