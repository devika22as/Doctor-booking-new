import './Sidebar.css';
import { useState, useEffect } from 'react';
import axios from '../../utils/axios';
import { NavLink, useNavigate } from 'react-router-dom';

const Sidebar = () => {
  const navigate = useNavigate();
  const [doctor, setDoctor] = useState({
    email: '',
    firstName: '',
    lastName: '',
    qualification: '',
    image: '',
  });
  const onLogOut = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('ID');
    navigate('/doctor/login');
  };
  const getDocHome = async () => {
    const doctorID = localStorage.getItem('ID');
    const response = await axios.get(`/doctor/${doctorID}`);
    setDoctor(response.data);
  };
  useEffect(() => {
    getDocHome();
  }, []);
  return (
    <div className="sidebar">
      <div className="user_card">
        <img src={doctor.image} alt="" />
        <div className="details">
          <p>{`${doctor.firstName} ${doctor.lastName}`}</p>
          <p>{doctor.qualification}</p>
        </div>
      </div>
      <div className="menu">
        <NavLink to="/doctor/home" className="link">
          <p>Dashboard</p>
        </NavLink>
        <NavLink to="/doctor/bookings" className="link">
          <p>My Bookings</p>
        </NavLink>
        <NavLink to="/doctor/addslots" className="link">
          <p>Add slots</p>
        </NavLink>

        <p onClick={onLogOut}>Logout</p>
      </div>
    </div>
  );
};

export default Sidebar;
