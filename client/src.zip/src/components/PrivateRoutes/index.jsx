import { Navigate,Outlet } from "react-router-dom";
import { checkToken, getRole } from "../../utils/localFunction";

const PrivateRoute=(props)=>{
    return checkToken() && props.role == getRole() ? <Outlet/> : <Navigate to="/doctor/login"/>
}

export default PrivateRoute;