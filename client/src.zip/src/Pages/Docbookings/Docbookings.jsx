import React, { useEffect, useState } from 'react';
// import { List, Divider } from 'antd';
import './DocBookings.css';
import Sidebar from '../../components/Sidebar/Sidebar';
import axios from '../../utils/axios';

const Docbookings = () => {
  const [slotsData, setSlotsData] = useState([]);
  console.log(slotsData, 'slotsdata');

  useEffect(() => {
    const viewSlotData = async () => {
      try {
        const response = await axios.get('/slots');
        setSlotsData(response.data.data);
      } catch (e) {
        console.log(e);
      }
    };
    viewSlotData();
  }, []);

  return (
    <div className="home">
      <Sidebar />
      <div className="home-container">
        <div className="availability-container">
          <h2>My Slots Availability</h2>
          <div className="slotsDetails">
            {slotsData &&
              slotsData.map(item => (
                <div className='card_slots'>
                  <div className="card">
                    <h5>{item.date.split('T')[0]}</h5>{' '}
                  </div>
                  <div className="time_slots">
                  <h5>{item.timeFrom} - {item.timeTo}</h5>
                  <h5>Slots:{item.availableSlots}</h5>
                  </div>
                  
                </div>
              ))}
          </div>
          {/* <List
            itemLayout="horizontal"
            dataSource={slotsData}
            renderItem={item => (
              <List.Item>
                <List.Item.Meta
                  title={`Date: ${item.date.split('T')[0]}, Time: ${
                    item.timeFrom
                  } - ${item.timeTo}`}
                  description={`Available Slots: ${item.availableSlots}`}
                />
              </List.Item>
            )}
          /> */}
        </div>
      </div>
    </div>
  );
};

export default Docbookings;
