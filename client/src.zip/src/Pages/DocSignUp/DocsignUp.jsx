import './DocsignUp.css';
import { Input, Button } from 'antd';
import { useState, useRef } from 'react';
import { IoEyeOutline, IoEyeOffOutline } from 'react-icons/io5';
import { NavLink } from 'react-router-dom';

const DocsignUp = () => {
  const inputRef = useRef();
  const [showpassword, setShowPassword] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const [selectedName, setSelectedName] = useState(null);
  console.log(selectedName, 'selectedName');
  console.log(selectedImage, 'selectedImage');
  const onTogglePassword = () => {
    setShowPassword(!showpassword);
  };
  const handleImageChange = event => {
    const file = event.target.files[0];
    if (file) {
      setSelectedImage(file);
      setSelectedName(file.name);
    }
  };
  const removeImageAndname = () => {
    setSelectedImage(null);
    setSelectedName(null);
    inputRef.current.click();
  };
  return (
    <div className="signUpMain">
      <div className="doc_signup_form">
        <h1>SignUp</h1>
        <div className="name">
          <div className="fname">
            <label>First Name</label>
            <Input
              className="inputClass"
              placeholder="Enter your first name..."
            />
          </div>

          <div className="lname">
            <label>Last Name</label>
            <Input
              className="inputClass"
              placeholder="Enter your last name..."
            />
          </div>
        </div>
        <label>Email</label>
        <Input
          className="inputClass"
          placeholder="Enter your email address..."
        />
        <label>Qualification</label>
        <Input
          className="inputClass"
          placeholder="Enter your qulification..."
        />
        <label>Password</label>
        <div className="input-div" style={{ position: 'relative' }}>
          <Input
            className="inputClass"
            placeholder="password..."
            type={showpassword ? 'text' : 'password'}
          />
          <div className="passIcons" onClick={onTogglePassword}>
            {showpassword ? (
              <IoEyeOutline size={20} color="grey" />
            ) : (
              <IoEyeOffOutline size={20} color="grey" />
            )}
          </div>
        </div>
        <label>Confirm Password</label>
        <Input
          className="inputClass"
          placeholder="confirm password"
          type="password"
        />
        <label>Upload Image</label>
        <div className="uploadImage">
          <input
            ref={inputRef}
            id="upload"
            type="file"
            name="myImage"
            onChange={handleImageChange}
          />
          {selectedImage && (
            <div>
              <p>Image Name: {selectedName}</p> {/* Display image name here */}
              <img
                alt="not found"
                src={URL.createObjectURL(selectedImage)}
                style={{ width: '100px', height: '100px' }}
              />
              <br />
              <br />
              <button onClick={removeImageAndname}>Remove</button>
            </div>
          )}
        </div>

        <div className="signup_btn">
          <NavLink to="/doctor/login">
            <Button>Sign up</Button>
          </NavLink>{' '}
        </div>
      </div>
    </div>
  );
};

export default DocsignUp;
