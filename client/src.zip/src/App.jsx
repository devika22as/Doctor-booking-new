import 'react-toastify/dist/ReactToastify.css';
import './App.css';
import { Routes, Route, useLocation } from 'react-router-dom';
import DocLogin from './Pages/DocLogin/DocLogin';
import DocHome from './Pages/DocHome/DocHome';
import AddSlots from './Pages/DocAddSlots/AddSlots';
import DocBookings  from "./Pages/Docbookings/Docbookings";
import PrivateRoute from './components/PrivateRoutes';
import DocsignUp from './Pages/DocSignUp/DocsignUp';

const App = () => {
  return (
    <Routes>
      <Route path="/doctor/login" element={<DocLogin />} />
      <Route path="/doctor/signup" element={<DocsignUp />} />
      <Route element={<PrivateRoute role="DOCTOR" />}>
        <Route path="/doctor/home" element={<DocHome />} />
        <Route path="/doctor/addslots" element={<AddSlots />} />
        <Route path="/doctor/bookings" element={<DocBookings />} />

      </Route>
    </Routes>
  );
};

export default App;
