const express = require('express');
const router = express.Router();
const controllers = require('../controllers/department-controller');
const upload = require('../middlewares/upload');
const checkToken= require('../middlewares/checkToken')
router.get('/', checkToken,controllers.getDepartments);
router.post('/',checkToken, upload.single('image'), controllers.postDepartments);

module.exports = router;
